public class TestDAteDemo
{

	public static void main(String[] args) 
	{
		Date kritikaDOJ=null;
		kritikaDOJ=new Date();
		kritikaDOJ.setDate(25, 10, 2017);
		System.out.println(" My DOJ is : " +kritikaDOJ.disDate());
		
		Date dhritiDOJ=null;
		dhritiDOJ=new Date();
		dhritiDOJ.setDate(26, 10, 2017);
		System.out.println(" My DOJ is : " +dhritiDOJ.disDate());
	}
}
