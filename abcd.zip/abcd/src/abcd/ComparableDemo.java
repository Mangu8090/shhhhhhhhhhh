package abcd;

import java.util.Iterator;
import java.util.TreeSet;

public class ComparableDemo {

	public static void main(String[] args) {
		TreeSet<Emp> tset=new TreeSet<Emp>();
		tset.add(new Emp("harry",4000.00));
		tset.add(new Emp("jack",2000.00));
		tset.add(new Emp("hari",5000.00));
		
		/*Iterator iterator= tset.iterator();
		while(iterator.hasNext()){
			Object empObj=iterator.next();
			System.out.println(empObj +"\n");
		}*/
		
		for(Emp obj: tset)
			System.out.println(obj);
		

	}
}
