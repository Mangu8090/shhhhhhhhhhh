package abcd;

public class Emp implements Comparable {
	int empID;
	String empName;
	double empSal;
	
	
	public Emp(String empName, double empSal) {
		super();
		this.empName = empName;
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Emp [empID=" + empID + ", empName=" + empName + ", empSal="
				+ empSal + "]";
	}
	
	public int compareTo(Object o)
	{
		if(this.empSal==((Emp)o).empSal) return 0;
		else if(this.empSal>((Emp)o).empSal) return 1;
		else return -1;
		
	}
	
}
