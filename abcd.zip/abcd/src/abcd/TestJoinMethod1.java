package abcd;

/*class TestJoinMethod1 extends Thread{  
	 public void run(){  
	  for(int i=1;i<=5;i++){  
	   try{  
	    Thread.sleep(500);  
	   }catch(Exception e){System.out.println(e);}  
	  System.out.println(i);  
	  }  
	 }  
	public static void main(String args[]){  
	 TestJoinMethod1 t1=new TestJoinMethod1();  
	 TestJoinMethod1 t2=new TestJoinMethod1();  
	 TestJoinMethod1 t3=new TestJoinMethod1();  
	 t1.start();  
	 t2.start();  
	 t3.start();  
	 try{  
		  t1.join();  
		 }catch(Exception e){System.out.println(e);}  
	 }  
	}  */
/*class TestJoinMethod1 extends Thread{  
	 public void run(){  
	  for(int i=1;i<=5;i++){  
	   try{  
	    Thread.sleep(500);  
	   }catch(Exception e){System.out.println(e);}  
	  System.out.println(i);  
	  }  
	 }  
	public static void main(String args[]){  
	 TestJoinMethod1 t1=new TestJoinMethod1();  
	 TestJoinMethod1 t2=new TestJoinMethod1();  
	TestJoinMethod1 t3=new TestJoinMethod1();  
	 t1.start();  
	 try{  
	  t1.join(1500);  
	 }catch(Exception e){System.out.println(e);}  
	  
	 t2.start();  
	t3.start();  
	 }  
	}  */

class TestJoinMethod1 extends Thread{  
	 public void run(){  
	   System.out.println("running thread name is:"+Thread.currentThread().getName());  
	   System.out.println("running thread priority is:"+Thread.currentThread().getPriority());  
	  
	  }  
	 public static void main(String args[]){  
	  TestJoinMethod1 m1=new TestJoinMethod1();  
	  TestJoinMethod1 m2=new TestJoinMethod1();  
	  m1.setPriority(Thread.MAX_PRIORITY);  
	  m2.setPriority(Thread.MIN_PRIORITY);  
	  m1.start();  
	  m2.start();  
	   
	 }  
	}     