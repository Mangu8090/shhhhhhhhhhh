
interface Sporty {
void beSporty();
}
class Ferrari extends Car implements Sporty {
public void beSporty() {
// implement cool sporty method in a Ferrari-specific way
}
}
class RacingFlats extends AthleticShoe implements Sporty {
public void beSporty() {
// implement cool sporty method in a RacingFlat-specific way
}
}
class GolfClub implements Sporty {

	@Override
	public void beSporty() {
		// TODO Auto-generated method stub
		
	} }
class TestSportyThings {
public static void main (String [] args) {
	int[][] books = new int[3][];
	int[] numbers =new int[6];
	int[][] aNumber = {{7,1}};
	//books= aNumber;
	
	books[0]= numbers;
	for(int i=0;i<books.length;i++){
		for(int j:books[i]){
		System.out.println(j);}
	}
	//System.out.println(books);
	Sporty[] sportyThings = new Sporty[3];
	sportyThings[0] = new Ferrari(); // OK, Ferrari
// implements Sporty
	sportyThings[1] = new RacingFlats(); // OK, RacingFlats
// implements Sporty
	sportyThings[2] = new GolfClub(); // NOT ok..
// Not OK; GolfClub does not implement Sporty
// I don't care what anyone says
}
}