
public class KeywordThis {

 int size = 27;
public int setSize(int size) {
	size=this.size; // this.size means the current object's
// instance variable, size. The size
// on the right is the parameter
return size;
}

public static void main(String[] args) {
	System.out.println(new KeywordThis().setSize(4));
}
}