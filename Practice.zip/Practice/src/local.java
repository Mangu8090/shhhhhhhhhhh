
/*public class local {
	int count = 10;
		public int logIn() {
		
		return count;
		
		}
public static void main(String[] args) {
	local l=new local();
	int count=12;
	System.out.println(count);
}
}*/
public class local {
	 int count = 12;
		public int logIn() {
		int count = 10;
		return count;
		}
		public int doSomething(int i) {
		int count = i; // Won't compile! Can't access count outside
		// method logIn()
		return i;
		}
		public static void main(String[] args) {
			//System.out.println(new local().doSomething(220));
			//System.out.println(new local().count);
			System.out.println(new local().logIn());
	
		}
		}
