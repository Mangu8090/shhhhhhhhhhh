
public class Palindrome {

	public static int main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(args[1]);
return 0;
	}

}
