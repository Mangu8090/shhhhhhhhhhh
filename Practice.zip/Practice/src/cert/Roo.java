package cert;
public class Roo {
	
protected String doRooThings() {
// imagine the fun code that goes here
return "fun";
}
}