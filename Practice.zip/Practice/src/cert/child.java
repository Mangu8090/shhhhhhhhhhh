package cert;

import ffg.Parent;

class child extends Parent {
	
/*public static void cll(){
	
	System.out.println(x);
}*/


public static void main(String[] args) {
	System.out.println(x);
//cll(); // No problem; Child
// inherits x
}
}