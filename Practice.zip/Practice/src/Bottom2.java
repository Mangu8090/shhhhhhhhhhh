
class Top {
public Top(){};
public Top(String s) { System.out.print("B"); }
}
public class Bottom2 extends Top {
public Bottom2(String s) { 
	//super(s);
System.out.print("D"); }
public static void main(String [] args) {
	
	char x = 'e';
	switch (x) {
	case 'a': System.out.println("2");
	default: System.out.println("default");
	case 'b': System.out.println("3");
	case 'c': System.out.println("4");
	}
new Bottom2("C");
System.out.println(" ");
}
}
