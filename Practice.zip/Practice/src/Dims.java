class Dims {
 public static void main(String[] args) {
 int[][] a = {{1,2}, {3,4}};
 System.out.println(a);
 int[] b = (int[])a[1];
 Object o1 = a;
 System.out.println(o1);
int[][] a2 =   (int[][]) o1;
System.out.println(a2);
 int[][] b2 =  (int[][]) o1;
 System.out.println(b[1]);
 } }