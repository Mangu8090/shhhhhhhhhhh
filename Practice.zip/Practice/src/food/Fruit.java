package food;
public abstract class Fruit
{
	public  static String colour(){
		return "red";
	}
	public abstract void taste();
}
/*package food;
public class Fruit
{
	protected  String colour(){
		return "red";
	}
	public  void taste(){
		System.out.println("sweet");
		
	}
}*/
