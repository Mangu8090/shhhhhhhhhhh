package ffg;

public class Parent {
protected static int x = 9; // protected access


}
