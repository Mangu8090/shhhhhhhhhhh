package ffg;

import java.io.IOException;

interface SC  {
	public void close() 
	throws IOException, Exception;
}
class Snoo implements SC {

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

	
	
}

