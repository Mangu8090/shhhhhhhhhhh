package ffg;

class abd {
	public String colo(){
		return "abd";
	}
}

class defaul extends abd{
	public String colo(){
		return "abb";
	}
		public String col(){
			return "abc";
		}
		
public static void main(String[] args) {
			abd a=new defaul();
			System.out.println(a.colo());
}
}

