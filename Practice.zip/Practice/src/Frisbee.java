//import java.io.IOException;

public class Frisbee {
	
	/*public void Abc() throws Exception{
		
	}*/
 public static void main(String[] args) throws IOException {
	 int x = 0;
	 System.out.println(7/x);
 }
 }