package apple;

import food.Fruit;

public class Apple extends Fruit{
	

	@Override
	public void taste() {
		System.out.println("sweet");
		
	}
	
	public static void main(String[] args) {
		Fruit f=new Apple();
		System.out.println(Fruit.colour());
		f.taste();
	}

}
/*package apple;

import food.Fruit;

public class Apple extends Fruit{
	
	void abc()
	{
		System.out.println(colour());
	}
	public static void main(String[] args) {
		Fruit f=new Fruit();
		//System.out.println(colour());
		Apple v =  new Apple();
		v.abc();
		f.taste();
	}

}
*/