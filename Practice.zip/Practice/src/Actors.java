



class Actors {
	static void m(StringBuilder sb1){
		sb1.append("er");
	}
public static void main(String[] args) {
	StringBuilder sb2= new StringBuilder("moth");
	m(sb2);
	System.out.println(sb2);
char[] ca = {0x4e, '\u004e', 78};
System.out.println(ca[1]);
System.out.println((ca[0] == ca[1]) + " " + (ca[0] == ca[2]));
}
}