public class Test2 {
	/*
	 * public static void doChange(int[] arr){ for(int
	 * pos=0;pos<arr.length;pos++) arr[pos]=arr[pos]+1; }
	 */
	public static void main(String[] args) {
		int a = 0;
		a++;
		System.out.println(a++);
		System.out.println(a);
		/*
		 * int day = 1; switch (day) { case 7: System.out.print("Uranus"); case
		 * 6: System.out.print("Saturn"); case 1: System.out.print("Mercury");
		 * case 2: System.out.print("Venus"); case 3: System.out.print("Earth");
		 * case 4: System.out.print("Mars"); case 5:
		 * System.out.print("Jupiter"); }
		 */
		/*
		 * int var1 = -5; int var2 = --var1; System.out.println(var2); int var3
		 * = 0; if (var2 < 0) { var3 = var2++; } else { var3 = --var2; }
		 * System.out.println(var3);
		 */
		/*
		 * String s = " Java Duke "; s = s.trim(); System.out.println(s); int
		 * len=s.length(); System.out.print(len);
		 */
		/*
		 * int [] [] array = {{0}, {0, 1}, {0, 2, 4}, {0, 3, 6, 9}, {0, 4, 8,
		 * 12, 16}}; System.out.println(array [4][1]); System.out.println (array
		 * [1][4]);
		 */
		/*
		 * int[] arr={10,20,30}; doChange(arr); for(int x: arr) {
		 * System.out.println(x+","); } doChange(arr);
		 * System.out.println(arr[0]+","+arr[1]+","+arr[2]); }
		 */
	}
}
