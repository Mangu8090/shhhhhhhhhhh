

public class Snippet {
	String s = "bob";
	String[] sa = {"a", "bob"};
	
	public static void main(String[] args) {
		final String s2 = "bob";
	StringBuilder sb = new StringBuilder("bob");
	switch(sa[1]){
	switch(s2) {
	switch(sb.toString()) { // line 3
	case "ann": ; // line 4
	case s: ; // line 5
	case s2: ; // line 6
	}
	}
}