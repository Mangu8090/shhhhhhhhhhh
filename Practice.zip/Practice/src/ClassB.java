public class ClassB extends ClassA {
	static int x=12;
    public static void printStatic(){
        System.out.println("hi static from B");
    }
    public void printDynamic(){
        System.out.println("hi dynamic from B");
    }  
    


public static void main (String args[]){
    ClassA x1 = new ClassB();
    System.out.println(x1.x);
    x1.printStatic();
    x1.printDynamic();
    ClassB x2 = new ClassB();
    System.out.println(x2.x);
    x2.printStatic();
    x2.printDynamic();
}
}