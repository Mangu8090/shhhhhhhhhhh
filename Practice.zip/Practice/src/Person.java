// you can't create new objects from reference variable declared final
/*class Person
{
    String name;
    int age;
 
    public static void main(String[] args) {
    final  Person p1 = new Person();
        p1 = new Person(); //ERROR
 
        Person p2 = new Person();
        p1 = p2; //ERROR
        p1 = null; //ERROR
    }
}*/
//modifying name and age in final 
class Person
{
    String name;
    int age;
       
       public static void main(String[] args) {
              final Person p1 = new Person();
              p1.age = 12;
              p1.name = "John";
              //This is legal. You can modify the state of final reference.
             p1.age = 30; 
             p1.name = "Peter";
             System.out.println(p1.age +" "+ p1.name);
       }
}