public class X1{
	String str="default";
	int ivalue=17;
	X1(String s){
		str=s;
	}
	X1(int i){
		ivalue=i;
	}
	void print()
	{
		System.out.println(str +" "+ivalue);
	}
	public static void main(String[] args) {
		
		int a[]={1,2,3};
		for(int var: a)
		{	int i=1;
		while(i<=var){
		System.out.println(i++ + " "+var);}
		}
	
		new X1("hello").print();
		new X1(92).print();
	}
}
