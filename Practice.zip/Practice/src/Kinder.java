
 /*class Clidder {
private final void flipper() { System.out.println("Clidder"); }
}
public class Clidlet extends Clidder {
public final void flipper() { System.out.println("Clidlet"); }
public static void main(String [] args) {
new Clidlet().flipper();
}
}


class Top {
public Top(){};
public Top(String s) { System.out.print("B"); }
}
public class Bottom2 extends Top {
public Bottom2(String s) { 
	//super(s);
System.out.print("D"); }
public static void main(String [] args) {
new Bottom2("C");
System.out.println(" ");
}
}
*/

/*AgedP super this
(           { }
;

class AgedP {
public AgedP(){
this(4);
	}
public AgedP(int x) {
System.out.println("A");
}
}
public class Kinder extends AgedP {
public Kinder(){
	super();
}
public Kinder(int x) {
 super();
}
public static void main(String [] args) {
new Kinder();
}
}*/

class AgedP {
AgedP() {
	System.out.println("B");
	
}
public AgedP(int x) {
	System.out.println("A");
}
}
public class Kinder extends AgedP {
	Kinder(){
		this(1);
		System.out.println("D");
	}
public Kinder(int x) {
//super(1);
System.out.println("C");
}
public static void main(String [] args) {
new Kinder(1);
}
}