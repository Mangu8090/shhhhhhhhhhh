class Loopy {
 public static void main(String[] args) {
 int[] x = {7,6,5,4,3,2,1};
 // insert code here
 for(int y : x) {
 System.out.print(y + " ");
 }
 }
 }