
package notcert; // Not the package Roo is in
import cert.Roo;
class Cloo extends Roo{
public void testCloo() {
System.out.println(doRooThings());
}
}

class Toon extends Cloo{
public static void main(String[] args) {
Toon c = new Toon();
System.out.println(c.doRooThings()); // No problem; method
// is public
}
}