interface Gadget {
void doStuff();
}
abstract class Electronic {
abstract void getPower() ;
}
public class Tablet extends Electronic implements Gadget {
	
  public void doStuff() { System.out.print("show book "); }
 void getPower(){ System.out.print("plug in "); }
public static void main(String[] args) {
new Tablet().getPower();
new Tablet().doStuff();
}
}