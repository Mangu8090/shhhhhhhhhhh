
enum CoffeeSize { BIG, HUGE, OVERWHELMING } // this cannot be
//private or protected
class Coffee {
CoffeeSize size;
}
public class CoffeeTest1 {
public static void main(String[] args) {
Coffee drink = new Coffee();
drink.size = CoffeeSize.BIG; // enum outside class
System.out.println(drink.size);
}
}
/*public class CoffeeTest1 {
enum CoffeeSize { BIG, HUGE, OVERWHELMING }
CoffeeSize size;
public static void main(String[] args) {
CoffeeTest1 drink = new CoffeeTest1();
drink.size = CoffeeSize.BIG;
System.out.println(drink.size);
}*/
