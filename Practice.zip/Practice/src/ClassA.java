
public class ClassA {   
	static int x=9;
    public static void printStatic(){
    	
        System.out.println("hi static from A");
    }       
    public void printDynamic(){
        System.out.println("hi dynamic from A");
    }       
}