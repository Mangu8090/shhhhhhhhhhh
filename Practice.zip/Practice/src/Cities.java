import java.util.*; // ArrayList lives in .util
public class Cities {
public static void main(String[] args) {
	List c = new ArrayList(); // create an ArrayList, c
c.add("Oslo"); // add original cities
c.add("Paris");
c.add("Paris");
c.add("Rome");
c.add(1);

//int index = c.indexOf("Paris"); // find Paris' index
//System.out.println(c + " " + index);
c.add(1, "London");
// add London before Paris
System.out.println(c); // show the contents of c
}
}