
public class For {
	public static void main(String [] args) {
		String s = "bob";
		String[] sa = {"a", "bob"};
		final String s2 = "bob";
		StringBuilder sb = new StringBuilder("bob");
		switch(sa[1]) { // line 1
		switch("b" + "ob") { // line 2
		 switch(sb.toString()) { // line 3
		 case "ann": ; // line 4
		 case s: ; // line 5
		 case s2: ; // line 6
		/*for (int i = 0; i < 10; i++) {
			System.out.println("Inside loop"+i);
			continue;
			}*/
		/*boolean isTrue = true;
		outer:
		for(int i=0; i<5; i++) {
		while (isTrue) {
		System.out.println("Hello");
		break outer;
		} // end of inner while loop
		System.out.println("Outer loop."); // Won't print
		} // end of outer for loop
		System.out.println("Good-Bye");*/
		outer:
			for (int i=0; i<5; i++) {
			for (int j=0; j<5; j++) {
			System.out.println("Hello");
			continue outer;
			} // end of inner loop
			System.out.println("outer"); // Never prints
			}
			System.out.println("Good-Bye");
}
}
