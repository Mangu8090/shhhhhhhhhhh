
class Foo {
	

void doStuff() {
	final int x = 7;
this.doMore(x);


}


private void doMore(int x) {
	// TODO Auto-generated method stub
	//x=8;
	System.out.println(x);
}


public static void main(String[] args) {
	//int x=8;
	Foo fu=new Foo();
	fu.doStuff();
}
}