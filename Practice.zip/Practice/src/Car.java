class Car {}
class Subaru extends Car {}
class Ferrari1 extends Car {
	public static void main(String[] args) {
		Car [] myCars = {new Subaru(), new Car(), new Ferrari()};
	}
}

