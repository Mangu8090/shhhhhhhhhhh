
public class S {
public static void main(String[] args) {
	StringBuilder s=new StringBuilder("Java");
	s.append(" SE 6");
	s.replace(8, 9, "7");
	System.out.println(s);
}
}
