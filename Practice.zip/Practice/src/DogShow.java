
class Dogi {
 public void bark() { System.out.print("woof "); }
 }
 class Hound extends Dogi {
 public void sniff() { System.out.print("sniff "); }
 public void bark() { System.out.print("howl "); }
 }
 public class DogShow {
 public static void main(String[] args) { new DogShow().go(); }
 void go() {
 new Hound().bark();
 ((Dogi) new Hound()).bark();
// ((Dogi) new Hound()).sniff();
}
 }
