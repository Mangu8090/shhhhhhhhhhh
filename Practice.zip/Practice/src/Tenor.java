
 class Singer { public  static String sing() { return "la"; } }
public class Tenor extends Singer {
 public static String sing() { return "fa"; }
 public static void main(String[] args) {
 Tenor t = new Tenor();
 Singer s = new Tenor();
 byte f=9;
 byte u=0;
 u+=f;
 byte h=(byte) (f+u);
 System.out.println(Tenor.sing() + " " + Singer.sing());
 }
 }

//static me override nhi hota