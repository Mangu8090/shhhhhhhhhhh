import java.io.IOException;

class MyException {
/*void someMethod () {
try {
	doStuff();
} catch (MyException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
void doStuff() throws MyException {
try {
throw new MyException();
}
catch(MyException me) {
throw me;
}*/
	/*public void doStuff() throws IOException{
		}*/
	public static void main(String[] args) {
	 try{int x = Integer.parseInt("two");} 
	 catch(NumberFormatException e)
	 {
		 System.out.println(e.getMessage());
	 }
	 }
	 
	
}
