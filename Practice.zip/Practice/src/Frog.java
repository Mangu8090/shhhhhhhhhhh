
public class Frog {
		 int x = 3;
		public static void main (String [] args) {
			//Frog f = new Frog();
		System.out.println("x is " + new Frog().x);
		}
		}
 /*class Frog {
int frogSize=25;
public  int getFrogSize() {
return frogSize;
}
public Frog(int s) {
frogSize = s;
}
public Frog() {
	// TODO Auto-generated constructor stub
}
public static void main (String [] args) {
Frog f = new Frog();
System.out.println(f.frogSize); // Access instance
// method using f
}
}

*/