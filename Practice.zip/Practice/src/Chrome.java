
class X { void do1() { } }
 class Y extends X { void do2() { } }

 class Chrome {
 public static void main(String [] args) {
 X x1 = new X();
 X x2 = new Y();
 Y y1 = new Y();
 //x2.do2(); iske liye X me dono methods hona chahie
  //(Y)x2.do2(); ye cast krne ka sahi way nhi hai
 // x1.do1();
 ((Y)x1).do2();
 }
 }
