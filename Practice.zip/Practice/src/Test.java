
class Egg {

Egg(){System.out.println("will print first");}

 void print(){System.out.println("print 2nd");}

}

public class Test{

public static void main(String[] args) {
StringBuilder sb=new StringBuilder();
String h="HelloWorld";
sb.append("Hello").append("World");
if(h==sb.toString()){
	System.out.println("a");
}
if(h.equals(sb.toString()))
	System.out.println("b"+sb);
}
Egg egg=new Egg();// this will call the constructor

//egg.print();// this can be called after Egg is created.

}
