
public class Employee {
	
    int id;
   String name;
    float salary;
    char gender;
    
    public Employee()
    {
 	   salary= 0;
 	   gender=' ';
 	   
    }
    public Employee(int id,String name,char gender){
  	   
  	   this.id=id;
  	   this.name=name;
  	   this.gender=gender;
     }
    public Employee(int id,String name,float salary,char gender){
 	   
 	   this.id=id;
 	   this.name=name;
 	   this.salary=salary;
 	   this.gender=gender;
    }
    
    public String dispDetail()
    {
 	   return id+" \n"+name+"\n "+salary+"\n "+gender;
    }
}
