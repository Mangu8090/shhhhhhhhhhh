
public class Ointment extends Medicines{

	String type;
public Ointment()
{
	super();
}
public Ointment(String Name, String cmpName, String expDate, float price,
		String type)
{
	super(Name,cmpName,expDate,price);
	this.type=type;
	
}
public String toString()
{
	return super.toString() +"type:"+type+ "\nStore at cool and dry place";
}
}