
class Calc{
	public void add(String name,int ...nums)                // int a,int b
	{
		int sum=0;
		//sum=a+b;
		for(int temp:nums)
		{
			sum=sum+temp;
		}
		System.out.println( "Sum="+sum);
	}
}

class TestVarDemo {
	public static void main(String[] args){
		Calc cc=new Calc();
		//cc.add(50,70);
		cc.add("Jin",10,70,50);
	}
}