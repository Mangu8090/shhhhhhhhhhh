import java.util.Scanner;


public class ArrayScan {
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		Emp emps[]=new Emp[3];
		for(int i=0;i<3;i++){
			//System.out.println("Enter choice");
			
			System.out.println("Type s: sales manager, Type e for employee, Type w for wageemp\n");
			String type= sc.next();
			
		switch(type)
		{
		case "s":
			System.out.println("Enter employee id");
			int eid=sc.nextInt();
			System.out.println("Enter employee name");
			String ename=sc.next();
			System.out.println("Enter employee salary");
			float sal=sc.nextInt();
			System.out.println("Enter no. of hours ");
			int hrs=sc.nextInt();
			System.out.println("Enter rate per hour");
			int rph=sc.nextInt();
			System.out.println("Enter no of sale");
			int nos=sc.nextInt();
			System.out.println("Enter commission");
			float comm=sc.nextInt();
			emps[i]= new SalesMgr(eid,ename,sal,hrs,rph,nos,comm);
			break;
		case "e":
			System.out.println("Enter employee id");
			eid=sc.nextInt();
			System.out.println("Enter employee name");
			ename=sc.next();
			System.out.println("Enter employee salary");
			sal=sc.nextInt();
			emps[i]= new Emp(eid,ename,sal);
			break;
		case "w":
			System.out.println("Enter employee id");
			eid=sc.nextInt();
			System.out.println("Enter employee name");
			ename=sc.next();
			System.out.println("Enter employee salary");
			sal=sc.nextInt();
			System.out.println("Enter no. of hours ");
			hrs=sc.nextInt();
			System.out.println("Enter rate per hour");
			rph=sc.nextInt();
			emps[i]= new WageEmp(eid,ename,sal,hrs,rph);
			break;
		default:
			System.out.println("wrong");
		}
		System.out.println( "Employee["+i+"]" +emps[i].dispEmpInfo());
		
		}
	
}}
	
