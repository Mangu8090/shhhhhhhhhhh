
public class Syrup extends Medicines{
 String type;
public Syrup()
{
	super();
}
public Syrup(String Name, String cmpName, String expDate, float price,
		String type)
{
	super(Name,cmpName,expDate,price);
	this.type=type;
	
}
public String toString()
{
	return super.toString() +"type:"+type+ "Shake well before use";
}
}