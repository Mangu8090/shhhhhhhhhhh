import java.util.Scanner;


public class TestAccountDemo {

	public static void main(String[] args) {
	try(Scanner sc=new Scanner(System.in)){
	int currentBalance=50000;
	System.out.println("Enter Withdraw Amount:");
	int withDrawAmt=sc.nextInt();
	if(withDrawAmt>currentBalance)
	{
		try
		{
			throw new LowBalanceException
			("Insufficient balance");
		}
		catch(LowBalanceException e)
		{
			System.out.println(e);
		}
	}
	else{
		System.out.println("Uhave");
	}
	}
catch(Exception e){
	e.printStackTrace();
}
}
}