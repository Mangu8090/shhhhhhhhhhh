
public class TestEmployee {

		public static void main(String[] args) 
		{
			Employee obj= new Employee(1,"jainisha",1000.0F,'F');
			System.out.println(obj.dispDetail());
			
			Employee obj2= new Employee();
			System.out.println(obj2.dispDetail());
			
			Employee obj3= new Employee(2,"jain",'M');
			System.out.println(obj3.dispDetail());	
		}

	}
