
public class SalesMgr extends WageEmp{

	int noOfSale;
	float commission;
	public SalesMgr()
	{ super();
	}
	public SalesMgr(int empId,String empName,float empSal,int noOfHrs,int ratePerHrs,int noOfSale,float commission)
	{
		super(empId, empName, empSal,noOfHrs,ratePerHrs);
		this.noOfSale= noOfSale;
		this.commission=commission;
		
	}
	public float calcAnnual()
	{
		return (super.calcAnnual())+(noOfSale*commission/100);
	}
	}
