
public interface Sortable {
	Sortable sort(Sortable list[]);
	
}
