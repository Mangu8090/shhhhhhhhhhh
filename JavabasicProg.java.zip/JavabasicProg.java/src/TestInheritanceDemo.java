
public class TestInheritanceDemo {

	public static void main(String[] args)
	{
		Emp Jaini=new Emp(111,"jeeni",10000.0F);
		WageEmp sam=new WageEmp(222,"sam",2000.0F,5,400);
		System.out.println(Jaini.dispEmpInfo());
		System.out.println(sam.dispEmpInfo());
		System.out.println("annual sal of jaini is" +Jaini.calcAnnual());
		System.out.println(" annual sal of sam is" +sam.calcAnnual());
		Emp maul=new WageEmp(333,"Maul",6000,6,400);
		System.out.println(maul.dispEmpInfo());
		System.out.println("annual sal of mauli is" +maul.calcAnnual());
		SalesMgr priya= new SalesMgr(452,"priya",5000,5,40000,2,4);
		System.out.println(priya.dispEmpInfo());
		System.out.println("annual sal of priya is" +priya.calcAnnual());

}
}
