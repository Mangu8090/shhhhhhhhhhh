class Pos
{
	int num;
	public void Calc(int num){
	if(num>0)
		{System.out.println(" positive");}
		else
		{System.out.println("negative");}
}
}
public class PosNeg {
	public static void main(String[] args) {
		Pos obj=new Pos();
		System.out.println("");
		obj.Calc(70);

}
}