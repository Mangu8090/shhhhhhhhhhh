import java.util.Scanner;
public class TestMedicines {
	
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter size:");
		int size= sc.nextInt();
		Medicines med[]=new Medicines[size];
		for(int i=0;i<size;i++){
			//System.out.println("Enter choice");
			
			System.out.println("Type t: tablet, Type o:Ointment, Type s:Syrup\n");
			String type= sc.next();
			
		switch(type)
		{
		case "t":
			System.out.println("Enter tablet name");
			String tname=sc.next();
			System.out.println("Enter company name");
			String cname=sc.next();
			System.out.println("Enter expiry date");
			String dte=sc.next();
			System.out.println("Enter price ");
			float price=sc.nextInt();
			type="Tablet";
			med[i]= new Tablet(tname,cname,dte,price,type);
			break;
		case "o":
			System.out.println("Enter ointment name");
			String oname=sc.next();
			System.out.println("Enter company name");
			String cnme=sc.next();
			System.out.println("Enter expiry date");
			String dt=sc.next();
			System.out.println("Enter price ");
			float prce=sc.nextInt();
			type="Ointment";
			med[i]= new Ointment(oname,cnme,dt,prce,type);
			break;
		case "s":
			System.out.println("Enter syrup name");
			String sname=sc.next();
			System.out.println("Enter company name");
			String scnme=sc.next();
			System.out.println("Enter expiry date");
			String dat=sc.next();
			System.out.println("Enter price ");
			float prc=sc.nextInt();
			type="Syrup";
			med[i]= new Syrup(sname,scnme,dat,prc,type);
			break;
		default:
			System.out.println("wrong choice");
		}
		System.out.println( med[i].toString());
		
		}
	
}}
	
