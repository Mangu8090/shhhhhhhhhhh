import java.util.Scanner;


public class TestEmp {
	static{
		System.out.println("static block is invoked at time"+ " when the classes are loaded in the"
	+" Memory by class loader");
		
	}
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size:");
		int size=sc.nextInt();
		Emp emps[]= new Emp[size];
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter Emp id:");
			int eid=sc.nextInt();
			System.out.println("Enter Emp name:");
			String enm=sc.next();
			System.out.println("Enter Emp Salary:");
			float esl=sc.nextFloat();
			emps[i]=new Emp(eid,enm,esl);
			
			
		}
		for(int i=0;i<size;i++)
		{
			System.out.println("\n Emp info:"+emps[i].dispEmpInfo());
		   System.out.println("Annual:"+emps[i].calcAnnual());
		   
		}
		
		Emp.getCount();
		
		
		sc.close();
		
		//emps[0]=new Emp(111,"Siya",2000.0F);
		//emps[1]=new Emp(112,"Seema",1000.0F);
		//emps[2]=new Emp(113,"Piya",3000.0F);
		

		//for(int i=0;i<emps.length;i++)
		
		//System.out.println(i+ "th emp info" + emps[i].dispEmpInfo());
		//System.out.println("Annual Salary:"+emps[i].calcAnnual());
		//}
		
}}
