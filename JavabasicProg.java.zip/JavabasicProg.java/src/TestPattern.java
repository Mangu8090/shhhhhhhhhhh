import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TestPattern {

	public static void main(String[] args) {
		
		String inputstr="Test String";
		String patern="Test String";
		
		boolean patternMatched=Pattern.matches(patern, inputstr);
		System.out.println(patternMatched);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ur name");
		String  fn= sc.next();
		String np="[A=z][a-z]+";
		
		if(Pattern.matches(np, fn))
		{
			System.out.println(" Hi:"+fn);
		}
		else{
			System.out.println("capi");}
		
		System.out.println("*********");
		String input= "shop,mop,hop,chop";
		Pattern pattern= Pattern.compile("hop");
		Matcher matcher=pattern.matcher(input);
		System.out.println("*********"+matcher.matches());
		while(matcher.find())
		{
			System.out.println(matcher.group()+":"+ matcher.start()+":"+matcher.end());
		}
	}

}
