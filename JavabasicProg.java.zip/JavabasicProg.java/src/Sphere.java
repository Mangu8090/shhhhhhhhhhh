
public class Sphere extends Shape{

	public Sphere()
	{
}
	public Sphere(int rad)
	{
		super(rad,"Sphere");
	}
	@Override
	public float calcArea()
	{
		return (float)(4*Math.PI*getRadius()*getRadius());
	}
	@Override
	public float calcCircum() {
		
		return (float) ((4/3)*Math.PI*getRadius()*getRadius()*getRadius());
	}
	
}
