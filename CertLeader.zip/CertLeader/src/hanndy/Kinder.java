package hanndy;
class AgedP {
AgedP() {}
public AgedP(int x) {
	System.out.println("ab");
}
}
public class Kinder extends AgedP {
public Kinder(int x) {
super();
System.out.println("a");
}
}