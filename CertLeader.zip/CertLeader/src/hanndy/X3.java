package hanndy;

public class X3 {
	static int i;
	int j;

	public static void main(String[] args) {
		int[] array = { 1, 2, 3, 4, 5 };
		for (int i : array) {
			if (i < 2) {
		break	;
			}
			System.out.println(i);
			if (i == 3) {
		break		;
			}
		}
		X3 x1 = new X3();
		X3 x2 = new X3();
		x1.i = 3;
		x1.j = 4;
		i = 5;
		x2.j = x1.j;
		x2.j = 6;
		System.out.println(x1.i + " " + x1.j + " " + x2.i + " " + x2.j);
	}
}