package hanndy;

public class Snippet {
	public static void main(String[] args) {
		System.out.println(array[pos])
	}
}

