package hanndy;

public class ComputeSum {
	public int x;
	public int y;
	public int sum;

	public ComputeSum(int nx, int ny) {
		x = nx;
		y = ny;
		updateSum();
	}

	public void setX(int nx) {
		x = nx;
		updateSum();
	}

	public void setY(int ny) {
		y = ny;
		updateSum();
	}

	void updateSum() {
		sum = x + y;
	}
}