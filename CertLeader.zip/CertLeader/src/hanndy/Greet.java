package hanndy;

//import handy.dandy.KeyStroke;



public class Greet {
public static void main(String[] args) {
	String greeting="Hello";
	System.out.println(greeting);
	handy.dandy.KeyStroke stroke=new handy.dandy.KeyStroke();
	stroke.type();
}
}
