package hanndy;
class X{
	public void mX(){
		System.out.println("x");
	}
}
class Y extends X{
	public void mX(){
		System.out.println("y");
	}
	
	public void my(){
		System.out.println("m");
	}
}
public class Test {
public static void main(String[] args) {
	String s="abc";
	String s1="abc";
	String s2="result:"+ s;
	System.out.println(s2==s1);
	
	X x1=new Y();
	//((Y) x1).my(); ye chlega aur my dega Y wala
	Y y1= (Y) x1;
	y1.my();
	/*y1.mX(); CLasscast*/
	/*X x2=new X();
	((Y) x2).my();
	Class cast*/
	
	x1.mX();
}
}
