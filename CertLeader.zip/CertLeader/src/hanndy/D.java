package hanndy;

public class D {
	public static void main(String[] args) {
		char b=65535;
		byte c=127;
		short a=32767;
		/*
		 * int b=4; int c=b--; System.out.println(c); System.out.println(b);
		 */
		String[] table = { "aa", "bb", "cc" };
		for (String ss : table) {
			int ii = 0;
			while (ii < table.length) {
				System.out.println(ss + " " + ii);
				ii++;
				break;
			}

		}
	}
}
