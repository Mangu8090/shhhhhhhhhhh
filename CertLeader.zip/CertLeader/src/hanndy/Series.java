package hanndy;

import java.io.FileNotFoundException;
import java.io.IOException;

interface SampleClosable {
	public void close () throws IOException;
	}
public class Series implements SampleClosable {
	public void close () { 
}
}
