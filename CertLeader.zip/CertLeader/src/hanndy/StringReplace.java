package hanndy;
public class StringReplace {
	String str="default";
	StringReplace(String s){str=s;}
	void print(){System.out.println(str);}
public static void main(String[] args) {
	new StringReplace("hello").print();
}
}
