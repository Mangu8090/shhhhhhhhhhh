package hanndy;

 class ABb {
static void one(){
	two(); 
	ABb.two();
	three(); // static ke andar non static direct nhi aaega par
	four();
}
static void two(){}
void three(){
	one();
	ABb.two();
	four(); // non static ke andar non static call aur static ho skta direct
	ABb.four();
}
	void four(){
}
}
