package hanndy;

class Shape{}

class Square extends Shape{}


public class Sss {
	static Shape shape1=null;
	static Square square1=null;
	public static void main(String[] args) {
shape1=(Square)new Square();
shape1=new Square();
square1=(Square)new Shape();
square1=new Shape();
square1=new Square();
shape1=square1;
shape1=new Shape();
square1=shape1;
}
}
