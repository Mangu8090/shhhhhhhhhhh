class Traveller{
	public static void main(String[] args) {
		System.out.println("h "+args[1]);
	}
}
public class Tours {
public static void main(String[] args) {
	for (int ii = 0; ii < 4; ii++) { System.out.println("ii = "+ ii); ii = ii +1;
	System.out.println(ii);
	}
	Traveller.main(args);
}
}
