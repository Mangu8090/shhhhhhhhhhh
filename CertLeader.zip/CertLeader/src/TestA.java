class Alpha{
	int ns;
	static int s;
	Alpha(int ns){
		if(s<ns){
			s=ns;
			this.ns=ns;
		}
			
	}
	void doPrint(){
		System.out.println(ns+" "+s);
	}
}

public class TestA {
public static void main(String[] args) {
	Alpha r1=new Alpha(50);
	r1.doPrint();
	Alpha r2=new Alpha(125);
	r2.doPrint();
	Alpha r3=new Alpha(100);
	r3.doPrint();
}
}
