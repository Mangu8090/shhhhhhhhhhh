public class Speak {
public static void main(String[] args) {
	Speak s=new Tell();
	Tell t= new Tell();
	//s.tell();
	//(Truth)s.tell();
	((Truth)s).tell();
	t.tell();
//	(Truth)t.tell();
	((Truth)t).tell();
	
}
}
class Tell extends Speak implements Truth{
	public void tell(){
		System.out.println("a");
	}
}
interface Truth{
	public void tell();
}