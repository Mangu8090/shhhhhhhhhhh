class Alpha1{ 
	public String[] main=new String[2];
	Alpha1(String[] main)
	{
		for(int ii=0;ii<main.length;ii++)
			this.main[ii]=main[ii]+5;
	}
	public void main(){
		System.out.println(main[0] + main[1]);
	}
}
public class B {
public static void main(String[] args) {
	int[] a1={1,2,3,4,5};
	for(int i:a1){
		if(i<2)
			continue;
		System.out.println(i);
		if(i==3)
			break;
		
	}
 	Alpha1 main=new Alpha1(args);
 	main.main();
}
}
