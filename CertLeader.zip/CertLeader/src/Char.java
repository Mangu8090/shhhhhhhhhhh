
public class Char {
public static void main(String[] args) {
	String s1="Java";
	char s2[]={'J','a','v','a'};
	String s3="";
	for(char c:s2){
		s3=s3+c;
	}
	if(s1.equals(s3))
		System.out.println(s1+" "+s3);
	else
		System.out.println(s1+" "+s3);
}
}
