public class TestLoop {
public static void main(String[] args) { int array[] = {0, 1, 2, 3, 4};
int key = 3;
int pos = 0;
try{
for (pos=0; pos < array.length; ++pos) { if (array[pos] == key) 
{
	System.out.println(array[pos]);
break;
}
}}
finally {
	System.out.println("a");
}
System.out.println("Found " + key + "at " + pos);
}
}