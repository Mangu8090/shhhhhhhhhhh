
public class Msg {
	 void m(int i){
		i+=7;
	}
public static String doMsg(char x){
	return "G";
}
public static String doMsg(int y){
	return "H";
}
public static void main(String[] args) {
	int j=12;
	new Msg().m(j);
	System.out.println(j);
	
	int z='8';
char x=8;
	System.out.println(doMsg(x));
	System.out.println(doMsg(z));
}
}
