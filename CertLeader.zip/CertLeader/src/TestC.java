class Caller{
	private int f=1;
	private void init(){
		System.out.println("a");
	}
	public void start(){
		init();
		System.out.println("b");
	}
}
public class TestC extends Caller{
public static void main(String[] args) {
	int r=10;
	for(;r>0;){
		int col=r;
		while(col>=0)
			System.out.println(col+" ");
		col-=2;
	}
	r=r/col;
}
//	Caller c=new Caller();
	//c.start();
	//c.init();
	//System.out.println(c.f);
}
}
