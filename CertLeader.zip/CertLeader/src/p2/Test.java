package p2;

import p1.Do;
import p3.DoC;

public class Test{
public static void main(String[] args) {
	int pos=0;
	/*try{
		for(pos=0;pos<10;pos++){
		}
	}
	catch*/
	Do d=new DoC();
d.m1(100)	;
d.m2(200);
}
}
