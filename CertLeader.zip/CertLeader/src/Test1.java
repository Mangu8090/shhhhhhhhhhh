public class Test1 {
	 Integer iObj = new Integer(10);
	int iVar = 10;
	
	 void doubling(Integer ref,  int pv) {
		this.iObj = 20;
		 this.iVar= 20;
		System.out.println(ref+ ""+pv);
	}

	public static void main(String[] args) {
		Test1 t=new Test1();
		 new Test1().doubling(t.iObj, t.iVar);
		System.out.println(t.iVar+ " "+t.iObj);
		//doubling(iObj++, iVar++);
		//Test1.doubling(ref, pv);
		
	}
}