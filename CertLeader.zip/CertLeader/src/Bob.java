class Star{
	public void doStuff(){
		System.out.println("TS");
	}
}
interface U{
	public void doStuff();
}
class Sun extends Star implements U{
	public void doStuff(){
		System.out.println("SS");
	}
}
public class Bob {
public static void main(String[] args) {
	Sun obj2=new Sun();
	
	Star obj=obj2;
	((Sun)obj).doStuff();
	((Star)obj2).doStuff();
	((U)obj2).doStuff();
	
}
}
