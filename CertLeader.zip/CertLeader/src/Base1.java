
 class Base1 {
abstract class Abs1{}

}
