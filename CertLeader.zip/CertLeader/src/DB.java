
//2.
public class DB {
 String user;
 String password;
 
}

class  ABC{
	DB config(String uname,String pass){
		return new DB();
		
		
	}
	public static void main(String[] args) {
		ABC a =new ABC();
	DB b =a.config("manager", "pass");
	}
}
