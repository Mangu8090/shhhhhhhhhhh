class X1{
	X1(){}
   protected void one(){System.out.println("a");}
}
public class Y extends X1{
Y(){}
 private void two(){one();}
public static void main(String[] args) {
	new Y().two();
}

}
