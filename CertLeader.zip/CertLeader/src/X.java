
 class X {
static int m(int i){
i+=7;
return i;
}
 public static void main(String[] args) {
	int j=12;
	System.out.println(m(j));
	System.out.println(j);
}
 
 }
