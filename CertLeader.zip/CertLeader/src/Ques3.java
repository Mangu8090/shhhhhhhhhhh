

import java.util.ArrayList;

public class Ques3 {
	public static void main(String[] args) {
	ArrayList<Integer> list = new ArrayList<>(1);
	list.add(1001);
	 list.add(1002);
	 //list.add(1003);
	 System.out.println(list);
	 System.out.println(list.get(list.size()));
}
}