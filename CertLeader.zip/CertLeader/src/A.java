
public class A {
public static void main(String[] args) {
	int[] a1={1,2,3,4,5};
	for(int i:a1){
		if(i<2){
			continue;}
		System.out.println(i);
		if(i==3){
			continue;
		}
	}
}
}

		
	/*System.arraycopy(a1, 0, a1, 2, 3);
	System.out.print(a1[0]);
	System.out.print(a1[2]);
	
	A a,b,c;
	a=new A();
	b=new B();
	c=new C();
	System.out.println("\nHash is:"+a);
}
public int getHash(){
	return 11111111;
}
}

class B extends A{
	public int getHash(){
		return 44444444;
	}
}
class C extends A{
	public int getHash(){
		return 999999999;
	}*/


