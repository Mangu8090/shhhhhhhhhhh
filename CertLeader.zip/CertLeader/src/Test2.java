
public class Test2 {
public static void main(String[] args) {
	int a[]=null;
	int b[]={5,6,7,8,9};
	b=a;
	for(int i:b)
		System.out.println(i);
	
}
}
