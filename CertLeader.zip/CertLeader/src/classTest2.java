
public class classTest2 {
int fvar;
static int cvar;
public static void main(String[] args) {
	classTest2 a=new classTest2();
	a.fvar=200;
	cvar=400;
	System.out.println(a.fvar);
	System.out.println(cvar);
}
}
