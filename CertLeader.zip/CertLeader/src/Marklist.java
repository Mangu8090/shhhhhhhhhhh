

public class Marklist {
public static void main(String[] args){ 
	int[] array = {1, 2, 3};
	for ( ;;) {
	}
}
}