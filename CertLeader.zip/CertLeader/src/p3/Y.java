package p3;

import java.io.IOException;

public class Y {
public static void main(String[] args) throws IOException {
	try{
		doS();
	}
	catch(RuntimeException e){
		System.out.println(e);
	}
}
	static void doS() throws IOException{
		if (Math.random()>0.5)
				throw new IOException();
		throw new RuntimeException();

}
}
