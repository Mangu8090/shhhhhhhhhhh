package p3;

public abstract class Wow {
 int wow;

public Wow(int wow) {
	super();
	this.wow = wow;
}
public void wow(){}
private void wowza(){}
 
public static void main(String[] args) {
	boolean a="true" != null;
	if(a)
		System.out.println("y");
}

}
