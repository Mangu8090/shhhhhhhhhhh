class Sports { int num_players;
String name, ground_condition;

/*public Sports() {
	super();
	// TODO Auto-generated constructor stub
}*/

Sports(int np, String sname, String sground){ num_players = np;
name = sname; ground_condition = sground;
}
}
class Cricket extends Sports { int num_umpires;
int num_substitutes;
Cricket() { 
	super(11, "Cricket", "Condidtion OK");
	this.num_umpires =3; this.num_substitutes=2;

}

/*Cricket() {
super(11, "Cricket", "Condidtion OK"); num_umpires =3; num_substitutes=2;
}*/

}