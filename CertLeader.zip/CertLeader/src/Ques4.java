

public class Ques4 {
public static void main(String[] args) {
	doStuff();
	int x1=x2;
	int x2=j;
}
static void doStuff(){
	System.out.println(j);
}
static int j;
}
