 
public class App {
// Insert code here
	int z=0;
	 public  static void main(String[] args) {
		 Access a1=new Access();
		 a1.
		App a =new App();
		int z=6;
		System.out.println(z);
		a.doStuff();
		System.out.println(z);
		System.out.println(a.z);
		/*for(int i=0;i<5;)
		 {System.out.println(i);}*/
		int[] lst={1,2,3,4,5,4,3,2,1,};
		int sum=0;
		for(int f=0,r=lst.length-1;f<5 && r>=5;f++,r--){
			sum=sum+lst[f]+lst[r];
		}
		System.out.println(sum);
//System.out.print("Welcome to the world of Java");
	 }
	 void doStuff() {
		// TODO Auto-generated method stub
	int z=5;
	doStuff2();
	System.out.println(z);
	}
	void doStuff2() {
		// TODO Auto-generated method stub
		z=4;
	}
}