class Base {
public static void main(String[] args) { System.out.println("Base " + args[2]);
}
}
public class Sub extends Base{
public static void main(String[] args) { 
	
	/*boolean log3 = ( 5.0 != 6.0) && ( 4 != 5);
	boolean log4 = (4 != 4)|| (4 == 4); 
	System.out.println("log3:"+ log3 + "\nlog4" + log4);*/
	//System.out.println("Overriden " + args[1]);
	for (int ii = 0; ii < 3;ii++) { int count = 0;
	for (int jj = 3; jj > 0; jj--) { if (ii == jj) {
	++count; break;
	}
	}
	System.out.print(count); continue;
	}
}
}