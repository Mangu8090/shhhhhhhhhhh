
public class Ques9 {
	
public static void main(String[] args) {
	int value=33;
	if(value>=0){
		if(value!=0)
			System.out.println("the ");
		else
			System.out.println("quick ");
		if(value<10)
			System.out.println("brown ");
		if(value>30)
			System.out.println("fox ");
		else if(value<50)
			System.out.println("jumps ");
		else if(value<10)
			System.out.println("over ");
		else
			System.out.println("the ");
		if(value>10)
			System.out.println("lazy ");
	}
	else
		{System.out.println("dog ");
		
}
	if(value>55)
		System.out.println("y");
System.out.println("...");
	}
}
