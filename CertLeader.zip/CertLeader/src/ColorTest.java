public class ColorTest {
	public static void main(String[] args) {
		String[] colors = { "red", "blue", "green", "yellow", "maroon", "cyan" };
		int count = 0;
		short b=32767;
		char a=65535;
		byte n=127;
		for (String c : colors) {
			if (count >= 4) {
				break;
			} else {
				count++;
				continue;
				
			}
			
			
		}
		System.out.println(colors[count+1]);
		}
	}
