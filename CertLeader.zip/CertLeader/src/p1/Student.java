package p1;
class TestStudent {
public String name = "";
public int age = 0;
public String major = "Undeclared";
public boolean fulltime = true;
public int year;
public void display() {
System.out.println("Name: " + name + " Major: " + major); }
public boolean isFullTime() {
return fulltime;
}
}
public class Student {
public static void main(String[] args) {
TestStudent bob = new TestStudent ();
bob.name = "Bob";
bob.age = 18;
bob.year = 1982;
bob.display();
}
}