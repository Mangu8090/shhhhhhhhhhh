package p1;

public class Test {
public static void main(String[] args) {
	Integer num= Integer.parseInt(args[1]);
	System.out.println("Number is"+num);
	Test ts=new Test();
	System.out.println(isAvailable+" ");
	isAvailable=ts.doStuff();
	System.out.println(isAvailable);
}
public static boolean doStuff(){
	return !isAvailable;
}
static boolean isAvailable=false;
}
