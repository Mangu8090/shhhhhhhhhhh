package p1;
 interface abc{
	int a1=2;
	void ab();
}
 class ab implements abc {
	 
public void ab() {
	a1=3;
	
}

}
public class abs{
	public static void main(String[] args) {
		ab a=new ab();
		
	}
}