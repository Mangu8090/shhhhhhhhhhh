package p1;

public interface Do {
void m1(int n);
public void m2(int n);
}
