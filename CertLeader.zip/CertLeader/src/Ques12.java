
public class Ques12 {
public static void main(String[] args) {
	int a=9;
	if(a++<10)
	{
		System.out.println(a+"h");
	}
	else
	{
		System.out.println(a+"b");
	}
}
}
