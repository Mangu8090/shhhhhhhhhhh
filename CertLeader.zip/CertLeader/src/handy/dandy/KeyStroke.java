package handy.dandy;

public class KeyStroke {
public void type()
{
	System.out.println("!");
}
}
