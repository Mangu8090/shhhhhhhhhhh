package handy.dandy;

public class X implements Z{
	public String toString(){return "I am x";}
public static void main(String[] args) {
	/*String color="teal";
	switch(color){
	case "red": System.out.println("red"); break;
	case "Teal": System.out.println("teal");break;
	default: System.out.println("a");*/
	
	Y y=new Y();
	X x=y;
	Z z=x;
	System.out.println(z);
}
}
class Y extends X{
	public String toString(){return "I am y";}
}
interface Z{}