package handy.dandy;
class Foo1 {
int barNum = 28;
}
public class Bar {
Foo1 myBar = new Foo1();
void changeIt(Foo1 myBar) {
myBar.barNum = 99;
System.out.println("myBar.barNum in changeIt is " + myBar.barNum);
//myBar = new Foo1();
myBar.barNum = 420;
System.out.println("myBar.barNum in changeIt is now " + myBar.barNum);
}
public static void main (String [] args) {
Bar f = new Bar();
System.out.println("f.myBar.barNum is " + f.myBar.barNum);
f.changeIt(f.myBar);
System.out.println("f.myBar.barNum after changeIt is "
+ f.myBar.barNum);
}
}