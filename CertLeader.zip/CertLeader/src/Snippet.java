
//1st.
public class Snippet {
	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder();
		sb.d
	float flt = 100F;
	 float flt1 = (float) 1_11.00;
	 float flt2 = 100;
	 double y1 = 203.22; 
	 float flt3 =  (float) y1;
	 int y2 = 100; 
	 int flt4 = y2;
}
}
