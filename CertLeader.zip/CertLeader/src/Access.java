
public class Access {
private int x=0;
private  int y=0;

public static void main(String[] args) {
	char c=65535;
	float v1=(12_345.01>=123_45.00)?12_456:124_56.02f;
	System.out.println(v1);
	float v2=v1+1024;
	System.out.println(v2);
	Access a=new Access();
	a.This(1,2);
	a.That(3,4);
}

public void That(int x, int y) {
	// TODO Auto-generated method stub
	this.x=x;
	this.y=y;
	System.out.println("x:"+this.x+"y:"+this.y);
}

public void This(int x, int y) {
	// TODO Auto-generated method stub
	x=x;
	y=y;
	System.out.println("x:"+this.x+"y:"+this.y);
}


}
