public class Natural { private int i;
void disp() { while (i <= 5) {
for (int i=1; i <=5;) { System.out.print(i + " "); i++;
} i++;
}
}
public static void main(String[] args) {
	int a=-10;
	int b=17;
	int c=++a;
		//System.out.println(c);
	int d=b--;
	c++;
	//System.out.println(g);
	d--;
	System.out.println(c+" "+d);
	new Natural().disp();
}
}