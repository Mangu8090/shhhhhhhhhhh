
public class TApp {
public static void main(String[] args) {
	TApp t=new TApp();
	try{
		t.doList();
		t.doPrint();
	} catch(Exception e2){
		System.out.println("Caught "+ e2);
	}
}

public void doList()throws Exception {
	// TODO Auto-generated method stub
	throw new Error("Error");
}

public void doPrint()throws Exception {
	// TODO Auto-generated method stub
	throw new RuntimeException("Exception");
}
}
