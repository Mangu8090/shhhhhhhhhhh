class Base12 {
public int num;

 protected int getNum() {
	return num;
}

 protected void setNum(int num) {
	this.num = num;
}

}
public class Derived extends Base12{ public static void main(String[] args) { Derived obj = new Derived();
obj.setNum(3);
System.out.println("Square = " + obj.getNum() * obj.getNum());
}
}