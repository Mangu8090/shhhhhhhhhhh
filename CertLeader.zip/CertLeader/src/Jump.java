
public class Jump {
static String args[]={"lazy","lion","is","always"};
public static void main(String[] args) {
	int num[];
	num=new int[2];
	num[0]=10;
	num[1]=20;
	
	num=new int[4];
	num[2]=11;
	num[3]=21;
	for(int j:num){
		System.out.println(j+"");
	
		
	}
	
	/*int[]x={6,7,8};
	for(int i:x){
		System.out.println(i+"");
		
	}
	
	System.out.println(args[1]+" "+args[2]+" "+args[3]+ "jumping");
*/}
}
