
public class Series {
public static void main(String[] args) {
	int a[]={1,2,3};
	for(int v:a){
		int i=1;
		while(i<=v);
		System.out.println(i++);
	}
}
}
