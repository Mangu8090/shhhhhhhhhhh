import java.util.Scanner;

class Factorial1
{
	int num;
	public int calFact(int number)
	{
		num=number;
		int fact=1;
		while(num>1)
		{
			fact=fact*num;
			num--;
		}
		return fact;
			
	}
}

public class Factorial
{
	public static void main(String[] args) 
	{
		Factorial1 obj1=new Factorial1();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Number: ");
		int num= sc.nextInt();
		System.out.println("Factorial Of Number is : "+obj1.calFact(num));
		sc.close();
	}
       
}