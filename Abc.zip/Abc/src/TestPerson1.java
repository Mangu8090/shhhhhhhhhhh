
public class TestPerson1 {

	public static void main(String[] args)
	{
		Date aDOB=new Date(12,01,1990);
		Date pDOB=new Date(10,8,1994);
		Date vDOB=new Date(14,9,1997);
		
		Person veena=new Person("CBF5645","Veena K",40000.0F,aDOB);
		Person veenu=new Person("CBF5645","Veena K",40000.0F,pDOB);
		
		System.out.println(" "+veena.dispPersonInfo());
		System.out.println(" "+veenu.dispPersonInfo());
		
		Person veen=new Person("CBF5645","Veena K",40000.0F,Gender.F,vDOB);
		System.out.println(" "+veen.dispPersonInfo());
		
	}

}
