class Animal{  
	int i=20;
public static void eat(){
	System.out.println("A");
}
}  
class Dog extends Animal{  
	int i=70;
	public static void eat(){
		System.out.println("D");
	}
}   
class Inheritance{  
public static void main(String args[]){  
Animal a= new Animal();	
Dog c=new Dog();   
Animal ac=new Dog();
c.eat();
//System.out.println("i="+ac.i);
}}  