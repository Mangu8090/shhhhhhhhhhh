public class Student 
{
	private int rollNo;
	private String stuName;
	private int marks;
	
	public Student()
	{
		
	}
	public int getRollNo()
	{
		return rollNo;
	}
	public void setRollNo(int rollNo)
	{
		this.rollNo=rollNo;
	}
	
	public String getStuName()
	{
		return stuName;
	}
	public void setStuName(String stuName)
	{
		this.stuName=stuName;
	}
	
	public int getMarks()
	{
		return marks;
	}
	public void setMarks(int marks)
	{
		this.marks=marks;
	}
	
	
	
}
