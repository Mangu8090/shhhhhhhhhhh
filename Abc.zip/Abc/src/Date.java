public class Date 
{
	int day;
	int mon;
	int year;

	public Date() {
		
	}

	public Date(int dd,int mm,int yy)
	{
		day=dd;
		mon=mm;
		year=yy;
	}
	
	public String disDate()
	{
		return day+"/"+mon+"/"+year;
	}
}
