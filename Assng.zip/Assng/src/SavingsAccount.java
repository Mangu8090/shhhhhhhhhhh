
public class SavingsAccount extends Account {

	final double minBal=500;
	
	public SavingsAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SavingsAccount(String name, float age, long accNum, double balance,
			Person accHolder) {
		super(name, age, accNum, balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	public void withdraw(double num) {
		if (balance > minBal && balance > num)
			newbalance = balance - num;
		else
			newbalance = balance;
		System.out.print("new balance : "+newbalance +"\n");

	}
	public String toString() {
		return super.toString();
	}
}