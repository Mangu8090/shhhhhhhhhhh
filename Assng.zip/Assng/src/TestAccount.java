import java.util.Scanner;

public class TestAccount {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Account smith = new Account();
		Account kathy = new Account();
		smith.setName("smith");
		kathy.setName("kathy");
		smith.setAge(21);
		kathy.setAge(22);
		smith.setBalance(2000);
		kathy.setBalance(3000);

		System.out.println(smith);
		System.out.println("Enter amount to  deposit");
		int num = sc.nextInt();
		System.out.println("new balance : " + smith.deposit(num));

		System.out.println(kathy.toString());
		System.out.println("Enter amount to withdraw");
		int num1 = sc.nextInt();
		kathy.withdraw(num1);

	}
}
