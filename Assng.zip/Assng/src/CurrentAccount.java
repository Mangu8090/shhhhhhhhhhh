
public class CurrentAccount extends Account{
final double overdraft=20000;

	public CurrentAccount() {
	super();
	// TODO Auto-generated constructor stub
}

public CurrentAccount(String name, float age, long accNum, double balance,
		Person accHolder) {
	super(name, age, accNum, balance, accHolder);
}


	public void withdraw(double num) {
		if ((balance-num)<overdraft &&(balance-num)>0){
			newbalance = balance - num;
			System.out.print("new balance : "+newbalance +"\n");
		}
		else{
			newbalance = balance;
		System.out.println("Overdraft limit reached!");
		System.out.println("false");}

	}
	public String toString() {
		return super.toString() ;
	}
}

