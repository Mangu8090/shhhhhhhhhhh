public class Account extends Person {
	 long accNum;
	 double balance;
     double newbalance;
	Person accHolder;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	public Account() {
		super();
	}

	public Account(String name, float age, long accNum, double balance,
			Person accHolder) {
		super(name, age);
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}

	public double deposit(double num) {
		if (balance>500 && num < 10000)
			newbalance = balance + num;
		else
			newbalance = balance;
		return newbalance;
	}

	public void withdraw(double num) {
		if (balance > 500 && balance > num)
			newbalance = balance - num;
		else
			newbalance = balance;
		System.out.print("new balance : "+newbalance +"\n");

	}

	public String toString() {
		return super.toString() + "\nAccount number: "
				+ (long) Math.floor(Math.random() * 9_000_000_000L)
				+ "\nbalance : " +balance+"\n";
	}
}
