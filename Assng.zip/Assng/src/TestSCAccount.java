import java.util.Scanner;
public class TestSCAccount {

	public static void main(String[] args) {

				Scanner sc = new Scanner(System.in);
				CurrentAccount s1 = new CurrentAccount();
				SavingsAccount s2 = new SavingsAccount();
				s1.setName("smith");
				s1.setAge(21);
				s1.setBalance(2000);
				s2.setName("kathy");
				s2.setAge(22);
				s2.setBalance(3000);

				System.out.println(s2.toString());
				System.out.println("Enter amount to  withdraw");
				int num = sc.nextInt();
				s2.withdraw(num);
				
				
				System.out.println(s1.toString());
				System.out.println("Enter amount to withdraw");
				int num1 = sc.nextInt();
				s1.withdraw(num1);

			}
		}


