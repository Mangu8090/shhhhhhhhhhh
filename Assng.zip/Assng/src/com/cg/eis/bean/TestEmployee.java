package com.cg.eis.bean;

import java.util.Scanner;

public class TestEmployee {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter sal");
		int salary=sc.nextInt();
		System.out.println("Enter id");
		int id= sc.nextInt();
		System.out.println("Enter name");
		String name=sc.next();
		if(salary>5000 && salary<20000){
			Employee a=new Employee(id,name,salary,"designation","scheme c");
			System.out.println(a.disp());
		}
		else if(salary>=20000 && salary<400000){
			Employee a=new Employee(id,name,salary,"prg","scheme B");
			System.out.println(a.disp());
		}
		else if(salary>=400000){
			Employee a=new Employee(id,name,salary,"manager","scheme A");
			System.out.println(a.disp());
		}
		else if(salary<5000){
			Employee a=new Employee(id,name,salary,"prg","no scheme ");
			System.out.println(a.disp());
		}
		
	}
}
