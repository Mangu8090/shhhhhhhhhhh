//5.1 In this package, create �Employee� class with 
//different attributes 
//such as id, name, salary, designation, insuranceScheme.
package com.cg.eis.bean;
public class Employee {
private int id;
private String name;
private int salary;
private String designation;
private String insuranceScheme;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(int id, String name, int salary, String designation,
		String insuranceScheme) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
	this.insuranceScheme = insuranceScheme;
}
public String disp()
{
	return "id:"+id+"\nname:"+name+"\nSalary"+salary+"\ndesignation:"+designation+"\ninsuranceScheme:"+insuranceScheme;
}

}
