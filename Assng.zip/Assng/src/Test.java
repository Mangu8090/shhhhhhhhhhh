import java.util.ArrayList;
import java.util.List;

class Student {
int rollnumber; String name;
List cources = new ArrayList();
public Student(int i, String string, List cs) {
	// TODO Auto-generated constructor stub
}
public void Student(int i, String name, List cs) {
/* initialization code goes here */
}
// insert code here public String toString() {
return rollnumber + " : " + name + " : " + cources;
}
}
public class Test {
public static void main(String[] args) { List cs = new ArrayList(); cs.add("Java");
cs.add("C");
Student s = new Student(123,"Fred", cs); System.out.println(s);
}