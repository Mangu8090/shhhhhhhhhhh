public class Test {

	// private static String[] arr;

	public static void main(String[] args) {
		int b = 3;
		if (!(b > 3))
			System.out.println("square ");
		System.out.println("circle ");
		System.out.println("...");
		/*
		 * System.out.println ("Result: " +3+5); System.out.println ("Result: "
		 * + (3+5)); arr[1] = "Unix"; arr[2] = "Linux"; arr[3] = "Solarios"; for
		 * (String var : arr) { System.out.print(var + " ");
		 */
	}
}
