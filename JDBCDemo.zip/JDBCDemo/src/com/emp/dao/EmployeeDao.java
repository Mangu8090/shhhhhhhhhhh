package com.emp.dao;

import com.emp.bean.EmployeeBean;
import com.emp.exception.*;

public interface EmployeeDao {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
}
