package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImp1 implements EmployeeDao{
public int generateEmployeeId(){
	int id=0;
	Connection con=DBConnection.getConnection();
	String qry="select es.nextval from dual";
	try {
		Statement stmt=con.createStatement();
		ResultSet rst=stmt.executeQuery(qry);
		rst.next();
		id=rst.getInt(1);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return id;
}
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con=DBConnection.getConnection();
		int id=0;
		String cmd="insert into emp_tbi(empid,ename,empsalary) values(?,?,?)";
		
		try {
			id=generateEmployeeId();
			PreparedStatement pstmt=con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEname());
			pstmt.setInt(3, bean.getEsal());
			
			int n=pstmt.executeUpdate();
			System.out.println(n);
		} catch (SQLException e) {
				
			e.printStackTrace();
			
		}
		return id;
	}

	
}
