package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnection {
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Reg Success");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "system";
			String pass = "orcl11g";
			try {
				Connection con = DriverManager.getConnection(url, user, pass);
				System.out.println("Conn success");
				Statement stmt = con.createStatement();
				String qry = "select empid,ename,empsalary from emp_tbi";
				ResultSet rst=stmt.executeQuery(qry);
				while (rst.next())
				{
					int id= rst.getInt("empid");
					String name= rst.getString("ename");
					int sal= rst.getInt("empsalary");
					System.out.println(id+" "+name+" "+sal);
				}
				
			} catch (SQLException e) {
				System.out.println(e);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
			// e.printStackTrace();
		}

	}
}
