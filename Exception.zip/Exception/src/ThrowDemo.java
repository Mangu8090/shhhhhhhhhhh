import java.io.IOException;


public class ThrowDemo
{
	public void method1() 
	{
		System.out.println("I am in method 1 ThrowDemo");
		method2();
	}
	

	public void method2()
	{
		System.out.println("I am in method 2 ThrowDemo");
		try
		{
		throw new IOException();
		}
		catch(IOException ie)
		{
			System.out.println("in");
			ie.printStackTrace();
		}
	}
}