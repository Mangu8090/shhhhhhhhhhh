
public class TestThrowsDemo {
	
	public static void main(String args[])
	{
		ThrowDemo et=new ThrowDemo();
		et.method1();
}
}